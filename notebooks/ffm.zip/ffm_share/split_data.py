import pandas as pd
from sklearn.model_selection import StratifiedShuffleSplit

file = './alltrainffm.txt'

all_data = pd.read_csv(file, sep=' ', header=0)
split_indices = all_data[all_data.columns[0]] #Stratified
nr_runs = 1
split_seed = 1117
test_ratio = 0.1
    

kf = StratifiedShuffleSplit(n_splits=nr_runs, 
                            test_size=test_ratio, train_size=None, 


                            random_state=split_seed)
for r, (train_index, valid_index) in enumerate(kf.split(all_data, split_indices), start=1):
    
    train = all_data.iloc[train_index]  
    valid = all_data.iloc[valid_index]
    print(train.shape, valid.shape)
    
    train.to_csv('./alltrainffm_train.txt', sep=' ', header=0, index=False)
    valid.to_csv('./alltrainffm_valid.txt', sep=' ', header=0, index=False)
