import pandas as pd

subm = pd.read_csv('../input/sample_submission.csv')
outputs = pd.read_csv('preds.txt',header=None)
subm['target'] = outputs.values.ravel()

#save round
filename = 'subm_{}_r.csv.gz'.format('ffm')
subm.to_csv(filename, index=False, compression='gzip', float_format='%.6f')  
print('\nSave to {} (rounded), shape={}'.format(filename, subm.shape))
